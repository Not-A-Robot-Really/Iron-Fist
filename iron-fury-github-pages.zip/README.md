# IRON FURY — Blood · Steel · Glory

A 2D pixel-art, Mortal Kombat-style street fighting game (1 Player vs CPU) built as a **single self-contained HTML file** — no assets, no dependencies, no build step. All art is procedurally generated on canvas and all audio is synthesized with WebAudio.

**▶ Play:** open `index.html` in any modern browser (or visit this repo's GitHub Pages site).

## Features
- **8 fighters** with unique traits, special moves and cinematic Ultimates
- **8 weapons** — Sword (bleed), Bow (pin), Dual Daggers (poison), War Hammer (stun), Frost Glaive (freeze), Inferno Whip (burn), Storm Chakram (shock), Kusarigama (pull)
- **6 animated pixel-art arenas** with hazards — Colosseum, Great Wall of China, New York alley, Iron Forge, Sakura Temple, Frozen Fjord
- **Elemental Reactions** (Shatter, Toxic Blast, Conduct, Hemorrhage, Neuroshock), **Blade Clash** duels, **disarm & steal**, crowd **Hype**, **FINISH THEM** finishers
- CPU AI with 4 difficulty levels, costume customization, practice mode

## Controls
| Key | Action |
|---|---|
| A / D | Move (double-tap to dash) |
| W / Space | Jump (again in air = double jump) |
| E | Punch |
| Q | Kick |
| F | Crouch (F+E uppercut, F+Q sweep) |
| R | Weapon strike (hold with bow to charge; pick up weapons) |
| 2 | Weapon Art |
| 1 | Ultimate (charges from damage dealt) |
| S | Block — tap just before a hit to Perfect Parry |
| Shift | Dodge roll / air dash |
| G | Grab / throw (in air: throw your weapon) |
| X | Swap weapon |
| Esc | Pause |

Combos: `E E Q` Iron Chain · `Q Q R` Rising Steel · `back fwd R` Steel Lunge · `F → fwd → E` character special.
